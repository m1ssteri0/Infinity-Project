var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var come_on;
var rect1 = createSprite(400, 187,20,20);
rect1.shapeColor =("white")

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);

 come_on =createSprite(20,190,13,13)
 come_on.shapeColor = ("green")

var c1 = createSprite(100, 130);
c1.shapeColor = ("red")
c1.scale = 0.1
var c2 = createSprite(215, 130);
c2.shapeColor = ("red")
c2.scale = 0.1
var c3 = createSprite(165, 250);
c3.scale = 0.1
c3.shapeColor = ("red")
var c4 = createSprite(270, 250);
c4.shapeColor = ("red")
c4.scale = 0.1

c1.velocityY = 8;
c2.velocityY = 8;
c3.velocityY = -8;
c4.velocityY = -8;




function draw() {
  background("white");
  text("Vidas: " + life,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
  

c1.bounceOff(boundary1);
c1.bounceOff(boundary2);
c2.bounceOff(boundary1);
c2.bounceOff(boundary2);
c3.bounceOff(boundary1); 
c3.bounceOff(boundary2);
c4.bounceOff(boundary1);
c4.bounceOff(boundary2);
come_on.bounceOff(boundary1)
come_on.bounceOff(boundary2)
 
if (come_on.isTouching(c1)) {
  come_on.x = 20
  come_on.y = 190
  life = life +1
}

if (come_on.isTouching(c2)) {
  come_on.x = 20
  come_on.y = 190
  life = life +1
}
  
  if (come_on.isTouching(c3)) {
  come_on.x = 20
  come_on.y = 190
  life = life +1
}
  
  if (come_on.isTouching(c4)) {
  come_on.x = 20
  come_on.y = 190
  life = life +1
}
  
if (come_on.isTouching(rect1)) {
fill("brown");
 textSize(18);
 text("Parabéns", 200, 147);
}
  
  
if(keyDown("right")){
    come_on.x = come_on.x+6;
    
  }
  
  if(keyDown("left")){
    come_on.x = come_on.x-6;
    
  }
  
drawSprites();

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
